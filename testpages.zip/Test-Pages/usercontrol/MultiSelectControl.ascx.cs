﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.UI.HtmlControls;
using Matrimonial.EntityLayer;
using Matrimonial.BusinessLayer;
using Matrimonial.Util;

namespace Test
{
    public partial class MultiSelectControl : System.Web.UI.UserControl
    {
        private List<string> _SelectedData;
        private string _Heading;

        #region Public Properties

        public string DataSource
        {
            get 
            {
                return ViewState["DataSource" + this.ID].ToString();
            }
            set
            {
                GeneralBL gen = new GeneralBL();
                ViewState["DataSource" + this.ID] = value;
                Cache[ViewState["DataSource" + this.ID].ToString()] = gen.GetMasterData(value);
            }
        }

        public string Heading
        {
            get { return this._Heading; }
            set { this._Heading = value; }
        }

        public List<string> GetSelectedItems
        {
            get { return ParseSelectedItems(); }
        }

        public List<string> SelectedData
        {
            get { return _SelectedData; }
            set { _SelectedData = value; }
        }

        public string DefaultSelect
        {
            get;
            set;
        }

        #endregion

        #region Event Method

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Initialise();
            }
            else 
            {
                Populate();
            }
        }

        #endregion

        #region Private Fields

        private List<string> ParseSelectedItems()
        {
            List<string> lstSelectedItems = new List<string>();
            var selectedTextStr = hdnSelectedItems.Value;
            if (selectedTextStr.Length > 0)
            {
                foreach (string selTetx in selectedTextStr.Split(','))
                {
                    var selectedRecord = GetValueFromText(selTetx);
                    if (selectedRecord != null)
                    {
                        lstSelectedItems.Add(selectedRecord.Code);
                    }
                }
            }

            this.SelectedData = lstSelectedItems;

            BindDataToUI();

            return lstSelectedItems;
        }

        private MasterData GetValueFromText(string text)
        {
            string value = string.Empty;
            List<MasterData> dataSource = GetDataSource() ;

            if (dataSource != null)
            {
                var dataRecord = dataSource.Where(item => item.Description == text);
                return dataRecord.FirstOrDefault();
            }
            return null;
        }

        private List<MasterData> GetDataSource()
        {
            List<MasterData> dataSource = null;
            if (ViewState["DataSource" + this.ID] != null)
            {
                if (Cache[ViewState["DataSource" + this.ID].ToString()] != null)
                {
                    dataSource = (List<MasterData>)Cache[ViewState["DataSource" + this.ID].ToString()];
                }
            }
            return dataSource;
        }

        private void Initialise()
        {

            /*
            List<string> str= new List<string>();
            for (int i = 1; i < 10; i++)
            {
                str.Add(i.ToString() + "Mukesh");
            }
           
            RptrItem.DataSource = this.DataSource; //str.Select(item => new { option = item });
            RptrItem.DataBind();
             */
            BindDataToUI();
        }

        private void BindDataToUI()
        {

            if (this.SelectedData != null && this.SelectedData.Count > 0)
            {
                hdnSelectedItems.Value = DataConverter.GetCommaSeperatedValues(this.SelectedData);
                List<MasterData> lstDataSource = GetDataSource();

                RptrSelectedItems.DataSource = lstDataSource.Where(item => this.SelectedData.Contains(item.Code));
                RptrSelectedItems.DataBind();

                var doesNotMatterObject = new MasterData() { Code = Constant.DoesnotMatterValue, Description = Constant.DoesnotMatterText };
                if (!this.SelectedData.Contains(Constant.DoesnotMatterValue))
                {
                    lstDataSource.Insert(0, doesNotMatterObject);
                }

                RptrItem.DataSource = lstDataSource.Where(item => !this.SelectedData.Contains(item.Code));
                RptrItem.DataBind();
            }
            else
            {
                RptrSelectedItems.DataSource = new List<MasterData>() { new MasterData(){ Code= Constant.DoesnotMatterValue , Description= Constant.DoesnotMatterText }  };
                RptrSelectedItems.DataBind();

                RptrItem.DataSource = GetDataSource();
                RptrItem.DataBind(); 
                
            }

            LblHeader.Text = this.Heading;
        }

        private void Populate()
        { 
        
        }
        #endregion
    }
}