﻿
$(function () {

    var DoesNotMatter = "Doesn't Matter";

    $(document).mouseup(function (e) {
        var container = $(".controlmain");
        if (!container.is(e.target) && container.has(e.target).length === 0) {
            $('.multiselectcontent').hide();
        }
    });

    $(".showhideitem").click(function () {
        var prevState = $(this).parents(".controlmain").find(".multiselectcontent").css("display");
        $(".multiselectcontent").hide();
        if (prevState != "block") {
            $(this).parents(".controlmain").find(".multiselectcontent").slideToggle(400);
        }

    });

    $(".multiselectcontent li").click(function () {
        if ($(this).text().trim() === DoesNotMatter) {
            ReSetSelection($(this).parents(".controlmain").find(":hidden"), $(this).parents(".controlmain").find("#selecteditemsli"), $(this).parents(".controlmain").find(".multiselectcontent ul"));
        }
        else {
            RemoveDoesNotMatterSelection($(this).parents(".controlmain").find("#selecteditemsli"), $(this).parents(".controlmain").find(".multiselectcontent ul"));
        }

        $(this).parents(".controlmain").find("#selecteditemsli").append("<li>" + $(this).text().trim() + "&nbsp;<font color='red'>x</font></li>"); //
        AddValue($(this).text(), $(this).parents(".controlmain").find(":hidden"));
        $(this).remove();
    });

    $(document).on("click", ".multiselectheader li", function () {

        var selText = $(this).text().trim().substr(0, $(this).text().trim().length - 1).trim(); ;
        if (selText.trim() === DoesNotMatter) {
            // $(this).parents(".controlmain").find(".multiselectcontent ul").prepend("<li>" + selText + "</li>");
        }
        else {
            $(this).parents(".controlmain").find(".multiselectcontent ul").append("<li>" + selText + "</li>");
        }

        if ($(this).parents(".controlmain").find("#selecteditemsli").find("li").size() == 1 && selText.trim() !== DoesNotMatter) {
            $(this).parents(".controlmain").find(".multiselectcontent ul").find("li").each(function (index) {
                if ($(this).text().trim() === DoesNotMatter) {
                    $(this).parents(".controlmain").find("#selecteditemsli").append("<li>" + $(this).text().trim() + "&nbsp;<font color='red'>x</font></li>");
                    $(this).remove();
                    return false;
                }
            });
        }

        RemoveValue(selText, $(this).parents(".controlmain").find(":hidden"));

        if (selText.trim() !== DoesNotMatter) {
            $(this).remove();
        }


    });

    $(document).on("click", ".multiselectcontent ul li", function () {

        if ($(this).text().trim() === DoesNotMatter) {
            ReSetSelection($(this).parents(".controlmain").find(":hidden"), $(this).parents(".controlmain").find("#selecteditemsli"), $(this).parents(".controlmain").find(".multiselectcontent ul"));
        }
        else {
            RemoveDoesNotMatterSelection($(this).parents(".controlmain").find("#selecteditemsli"), $(this).parents(".controlmain").find(".multiselectcontent ul"));
        }

        $(this).parents(".controlmain").find("#selecteditemsli").append("<li>" + $(this).text().trim() + "&nbsp;<font color='red'>x</font></li>");
        AddValue($(this).text().trim(), $(this).parents(".controlmain").find(":hidden"));
        $(this).remove();

    });

    function ReSetSelection(hdnFld, selecteditemUL, contentUL) {
        if (hdnFld != null) {
            hdnFld.val("");
        }

        selecteditemUL.find("li").each(function (index) {
            contentUL.append("<li>" + $(this).text().trim().substr(0, $(this).text().trim().length - 1).trim() + "</li>");
        });

        selecteditemUL.find("li").remove();

    }

    function RemoveDoesNotMatterSelection(selecteditemUL, contentUL) {
        selecteditemUL.find("li").each(function (index) {
            var selText = $(this).text().trim().substr(0, $(this).text().trim().length - 1).trim();
            if (selText === DoesNotMatter) {
                $(this).remove();
                contentUL.prepend("<li>" + selText + "</li>");
            }
        });
    }


    function AddValue(txt, hdnFld) {
        if (hdnFld == null) {
            return false;
        }

        if (txt.trim() === DoesNotMatter) {
            return;
        }

        var selectedElement = hdnFld.val();
        if (selectedElement === null || selectedElement === "") {
            hdnFld.val(txt.trim());
        }
        else {
            hdnFld.val(hdnFld.val() + "," + txt.trim());
        }
    }

    function RemoveValue(txt, hdnFld) {

        if (hdnFld == null) {
            return false;
        }

        if (txt.trim() === DoesNotMatter) {
            return;
        }

        var selectedElement = hdnFld.val().split(',');
        if (selectedElement === null || selectedElement.length === 0) {

            return false;
        }

        hdnFld.val("");
        for (var i = 0; i < selectedElement.length; i++) {
            if (selectedElement[i] !== txt.trim()) {
                if (hdnFld.val() === "") {
                    hdnFld.val(selectedElement[i]);
                }
                else {
                    hdnFld.val(hdnFld.val() + "," + selectedElement[i]);
                }
            }
        }
    }

});


